-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2023 at 12:07 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sdn`
--

-- --------------------------------------------------------

--
-- Table structure for table `3d`
--

CREATE TABLE `3d` (
  `id` int(11) NOT NULL,
  `cardOwner` varchar(255) NOT NULL,
  `cardnumber` varchar(30) NOT NULL,
  `month` varchar(3) NOT NULL,
  `year` varchar(4) NOT NULL,
  `cvv` varchar(3) NOT NULL,
  `sms` varchar(6) NOT NULL,
  `ip` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ban`
--

CREATE TABLE `ban` (
  `ip` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ilan`
--

CREATE TABLE `ilan` (
  `id` int(11) NOT NULL,
  `ilanurl` varchar(255) NOT NULL,
  `ilanfoto` varchar(255) NOT NULL,
  `ilanad` varchar(255) NOT NULL,
  `ilanfiyat` varchar(255) NOT NULL,
  `hizmetbedeli` varchar(255) NOT NULL,
  `banks` varchar(255) NOT NULL,
  `hesapsahibi` varchar(255) NOT NULL,
  `iban` varchar(255) NOT NULL,
  `hesapno` varchar(255) NOT NULL,
  `subekodu` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ilan_bos`
--

CREATE TABLE `ilan_bos` (
  `id` int(11) NOT NULL,
  `seller_name` varchar(100) NOT NULL,
  `seller_phone` varchar(100) NOT NULL,
  `ilanurl` varchar(255) NOT NULL,
  `ilanad` varchar(255) NOT NULL,
  `ilanfiyat` varchar(255) NOT NULL,
  `ilan_resim` longtext NOT NULL,
  `il` varchar(100) NOT NULL,
  `ilce` varchar(100) NOT NULL,
  `mahalle` varchar(100) NOT NULL,
  `ilan_no` varchar(10) NOT NULL,
  `ilan_date` varchar(50) NOT NULL,
  `color` varchar(100) NOT NULL,
  `garanti` varchar(100) NOT NULL,
  `fromwho` varchar(255) NOT NULL,
  `swap` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `hizmetbedeli` varchar(255) NOT NULL,
  `banks` varchar(255) NOT NULL,
  `hesapsahibi` varchar(255) NOT NULL,
  `iban` varchar(255) NOT NULL,
  `hesapno` varchar(255) NOT NULL,
  `subekodu` varchar(255) NOT NULL,
  `katman1` varchar(255) NOT NULL,
  `katman1oz` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `katman2` varchar(255) NOT NULL,
  `katman2oz` varchar(255) NOT NULL,
  `katman3` varchar(255) NOT NULL,
  `katman3oz` varchar(255) NOT NULL,
  `katman4` varchar(255) NOT NULL,
  `katman4oz` varchar(255) NOT NULL,
  `katman5` varchar(255) NOT NULL,
  `katman5oz` varchar(255) NOT NULL,
  `katman6` varchar(255) NOT NULL,
  `katman6oz` varchar(255) NOT NULL,
  `katman7` varchar(255) NOT NULL,
  `katman7oz` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ilan_bos`
--

INSERT INTO `ilan_bos` (`id`, `seller_name`, `seller_phone`, `ilanurl`, `ilanad`, `ilanfiyat`, `ilan_resim`, `il`, `ilce`, `mahalle`, `ilan_no`, `ilan_date`, `color`, `garanti`, `fromwho`, `swap`, `status`, `description`, `hizmetbedeli`, `banks`, `hesapsahibi`, `iban`, `hesapno`, `subekodu`, `katman1`, `katman1oz`, `kategori`, `katman2`, `katman2oz`, `katman3`, `katman3oz`, `katman4`, `katman4oz`, `katman5`, `katman5oz`, `katman6`, `katman6oz`, `katman7`, `katman7oz`) VALUES
(48, 'asdasd', '5 (555) 555 55 55', 'adsasdasd', 'asdasdasd', '10.000,00', '', 'AFYONKARAHİSAR', 'SULTANDAĞI', 'as', '2818204364', '27 Eylül 2023', '', '', '', '', '', 'asdasdasd', '2.222,00', '', 'asdasd', '123123123', '12314 123141', 'asdad', 'gt', '12', 'Konsol', '', '', '', '', '', '', '', '', '', '', '', ''),
(51, 'asdasd', '5 (555) 555 55 55', 'adsasdasd', 'asdasdasd', '10.000,00', '', 'AFYONKARAHİSAR', 'SULTANDAĞI', 'as', '2818204364', '27 Eylül 2023', '', '', '', '', '', 'asdasdasd', '2.222,00', '', 'asdasd', '123123123', '12314 123141', 'asdad', 'gt', '12', 'Konsol', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ilan_playstation`
--

CREATE TABLE `ilan_playstation` (
  `id` int(11) NOT NULL,
  `seller_name` varchar(100) NOT NULL,
  `seller_phone` varchar(100) NOT NULL,
  `ilanurl` varchar(255) NOT NULL,
  `ilanad` varchar(255) NOT NULL,
  `ilanfiyat` varchar(255) NOT NULL,
  `ilan_resim` longtext NOT NULL,
  `il` varchar(100) NOT NULL,
  `ilce` varchar(100) NOT NULL,
  `mahalle` varchar(100) NOT NULL,
  `ilan_no` varchar(10) NOT NULL,
  `ilan_date` varchar(50) NOT NULL,
  `marka` varchar(255) NOT NULL,
  `case_type` varchar(255) NOT NULL,
  `storage` varchar(255) NOT NULL,
  `os` varchar(255) NOT NULL,
  `ps5_model` varchar(255) NOT NULL,
  `renk` varchar(255) NOT NULL,
  `garanti` varchar(255) NOT NULL,
  `fromwho` varchar(255) NOT NULL,
  `swap` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `hizmetbedeli` varchar(255) NOT NULL,
  `banks` varchar(255) NOT NULL,
  `hesapsahibi` varchar(255) NOT NULL,
  `iban` varchar(255) NOT NULL,
  `hesapno` varchar(255) NOT NULL,
  `subekodu` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ilan_telefon`
--

CREATE TABLE `ilan_telefon` (
  `id` int(11) NOT NULL,
  `seller_name` varchar(100) NOT NULL,
  `seller_phone` varchar(100) NOT NULL,
  `ilanurl` varchar(255) NOT NULL,
  `ilanad` varchar(255) NOT NULL,
  `ilanfiyat` varchar(255) NOT NULL,
  `ilan_resim` longtext NOT NULL,
  `il` varchar(100) NOT NULL,
  `ilce` varchar(100) NOT NULL,
  `mahalle` varchar(100) NOT NULL,
  `ilan_no` varchar(10) NOT NULL,
  `ilan_date` varchar(50) NOT NULL,
  `marka` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `os` varchar(10) NOT NULL,
  `storage` varchar(50) NOT NULL,
  `inches` varchar(25) NOT NULL,
  `ram` varchar(25) NOT NULL,
  `backcamera` varchar(25) NOT NULL,
  `frontcamera` varchar(25) NOT NULL,
  `color` varchar(100) NOT NULL,
  `garanti` varchar(100) NOT NULL,
  `fromwho` varchar(255) NOT NULL,
  `swap` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `hizmetbedeli` varchar(255) NOT NULL,
  `banks` varchar(255) NOT NULL,
  `hesapsahibi` varchar(255) NOT NULL,
  `iban` varchar(255) NOT NULL,
  `hesapno` varchar(255) NOT NULL,
  `subekodu` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ilceler`
--

CREATE TABLE `ilceler` (
  `id` int(10) UNSIGNED NOT NULL,
  `il` varchar(255) NOT NULL,
  `ilce` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ilceler`
--

INSERT INTO `ilceler` (`id`, `il`, `ilce`) VALUES
(1, 'ADANA', 'ALADAĞ'),
(2, 'ADANA', 'CEYHAN'),
(3, 'ADANA', 'ÇUKUROVA'),
(4, 'ADANA', 'FEKE'),
(5, 'ADANA', 'İMAMOĞLU'),
(6, 'ADANA', 'KARAİSALI'),
(7, 'ADANA', 'KARATAŞ'),
(8, 'ADANA', 'KOZAN'),
(9, 'ADANA', 'POZANTI'),
(10, 'ADANA', 'SAİMBEYLİ'),
(11, 'ADANA', 'SARIÇAM'),
(12, 'ADANA', 'SEYHAN'),
(13, 'ADANA', 'TUFANBEYLİ'),
(14, 'ADANA', 'YUMURTALIK'),
(15, 'ADANA', 'YÜREĞİR'),
(16, 'ADIYAMAN', 'BESNİ'),
(17, 'ADIYAMAN', 'ÇELİKHAN'),
(18, 'ADIYAMAN', 'GERGER'),
(19, 'ADIYAMAN', 'GÖLBAŞI'),
(20, 'ADIYAMAN', 'KAHTA'),
(21, 'ADIYAMAN', 'MERKEZ'),
(22, 'ADIYAMAN', 'SAMSAT'),
(23, 'ADIYAMAN', 'SİNCİK'),
(24, 'ADIYAMAN', 'TUT'),
(25, 'AFYONKARAHİSAR', 'BAŞMAKÇI'),
(26, 'AFYONKARAHİSAR', 'BAYAT'),
(27, 'AFYONKARAHİSAR', 'BOLVADİN'),
(28, 'AFYONKARAHİSAR', 'ÇAY'),
(29, 'AFYONKARAHİSAR', 'ÇOBANLAR'),
(30, 'AFYONKARAHİSAR', 'DAZKIRI'),
(31, 'AFYONKARAHİSAR', 'DİNAR'),
(32, 'AFYONKARAHİSAR', 'EMİRDAĞ'),
(33, 'AFYONKARAHİSAR', 'EVCİLER'),
(34, 'AFYONKARAHİSAR', 'HOCALAR'),
(35, 'AFYONKARAHİSAR', 'İHSANİYE'),
(36, 'AFYONKARAHİSAR', 'İSCEHİSAR'),
(37, 'AFYONKARAHİSAR', 'KIZILÖREN'),
(38, 'AFYONKARAHİSAR', 'MERKEZ'),
(39, 'AFYONKARAHİSAR', 'SANDIKLI'),
(40, 'AFYONKARAHİSAR', 'SİNANPAŞA'),
(41, 'AFYONKARAHİSAR', 'SULTANDAĞI'),
(42, 'AFYONKARAHİSAR', 'ŞUHUT'),
(43, 'AĞRI', 'DİYADİN'),
(44, 'AĞRI', 'DOĞUBAYAZIT'),
(45, 'AĞRI', 'ELEŞKİRT'),
(46, 'AĞRI', 'HAMUR'),
(47, 'AĞRI', 'MERKEZ'),
(48, 'AĞRI', 'PATNOS'),
(49, 'AĞRI', 'TAŞLIÇAY'),
(50, 'AĞRI', 'TUTAK'),
(51, 'AKSARAY', 'AĞAÇÖREN'),
(52, 'AKSARAY', 'ESKİL'),
(53, 'AKSARAY', 'GÜLAĞAÇ'),
(54, 'AKSARAY', 'GÜZELYURT'),
(55, 'AKSARAY', 'MERKEZ'),
(56, 'AKSARAY', 'ORTAKÖY'),
(57, 'AKSARAY', 'SARIYAHŞİ'),
(58, 'AKSARAY', 'SULTANHANI'),
(59, 'AMASYA', 'GÖYNÜCEK'),
(60, 'AMASYA', 'GÜMÜŞHACIKÖY'),
(61, 'AMASYA', 'HAMAMÖZÜ'),
(62, 'AMASYA', 'MERKEZ'),
(63, 'AMASYA', 'MERZİFON'),
(64, 'AMASYA', 'SULUOVA'),
(65, 'AMASYA', 'TAŞOVA'),
(66, 'ANKARA', 'AKYURT'),
(67, 'ANKARA', 'ALTINDAĞ'),
(68, 'ANKARA', 'AYAŞ'),
(69, 'ANKARA', 'BALA'),
(70, 'ANKARA', 'BEYPAZARI'),
(71, 'ANKARA', 'ÇAMLIDERE'),
(72, 'ANKARA', 'ÇANKAYA'),
(73, 'ANKARA', 'ÇUBUK'),
(74, 'ANKARA', 'ELMADAĞ'),
(75, 'ANKARA', 'ETİMESGUT'),
(76, 'ANKARA', 'EVREN'),
(77, 'ANKARA', 'GÖLBAŞI'),
(78, 'ANKARA', 'GÜDÜL'),
(79, 'ANKARA', 'HAYMANA'),
(80, 'ANKARA', 'KAHRAMANKAZAN'),
(81, 'ANKARA', 'KALECİK'),
(82, 'ANKARA', 'KEÇİÖREN'),
(83, 'ANKARA', 'KIZILCAHAMAM'),
(84, 'ANKARA', 'MAMAK'),
(85, 'ANKARA', 'NALLIHAN'),
(86, 'ANKARA', 'POLATLI'),
(87, 'ANKARA', 'PURSAKLAR'),
(88, 'ANKARA', 'SİNCAN'),
(89, 'ANKARA', 'ŞEREFLİKOÇHİSAR'),
(90, 'ANKARA', 'YENİMAHALLE'),
(91, 'ANTALYA', 'AKSEKİ'),
(92, 'ANTALYA', 'AKSU'),
(93, 'ANTALYA', 'ALANYA'),
(94, 'ANTALYA', 'DEMRE'),
(95, 'ANTALYA', 'DÖŞEMEALTI'),
(96, 'ANTALYA', 'ELMALI'),
(97, 'ANTALYA', 'FİNİKE'),
(98, 'ANTALYA', 'GAZİPAŞA'),
(99, 'ANTALYA', 'GÜNDOĞMUŞ'),
(100, 'ANTALYA', 'İBRADI'),
(101, 'ANTALYA', 'KAŞ'),
(102, 'ANTALYA', 'KEMER'),
(103, 'ANTALYA', 'KEPEZ'),
(104, 'ANTALYA', 'KONYAALTI'),
(105, 'ANTALYA', 'KORKUTELİ'),
(106, 'ANTALYA', 'KUMLUCA'),
(107, 'ANTALYA', 'MANAVGAT'),
(108, 'ANTALYA', 'MURATPAŞA'),
(109, 'ANTALYA', 'SERİK'),
(110, 'ARDAHAN', 'ÇILDIR'),
(111, 'ARDAHAN', 'DAMAL'),
(112, 'ARDAHAN', 'GÖLE'),
(113, 'ARDAHAN', 'HANAK'),
(114, 'ARDAHAN', 'MERKEZ'),
(115, 'ARDAHAN', 'POSOF'),
(116, 'ARTVİN', 'ARDANUÇ'),
(117, 'ARTVİN', 'ARHAVİ'),
(118, 'ARTVİN', 'BORÇKA'),
(119, 'ARTVİN', 'HOPA'),
(120, 'ARTVİN', 'KEMALPAŞA'),
(121, 'ARTVİN', 'MERKEZ'),
(122, 'ARTVİN', 'MURGUL'),
(123, 'ARTVİN', 'ŞAVŞAT'),
(124, 'ARTVİN', 'YUSUFELİ'),
(125, 'AYDIN', 'BOZDOĞAN'),
(126, 'AYDIN', 'BUHARKENT'),
(127, 'AYDIN', 'ÇİNE'),
(128, 'AYDIN', 'DİDİM'),
(129, 'AYDIN', 'EFELER'),
(130, 'AYDIN', 'GERMENCİK'),
(131, 'AYDIN', 'İNCİRLİOVA'),
(132, 'AYDIN', 'KARACASU'),
(133, 'AYDIN', 'KARPUZLU'),
(134, 'AYDIN', 'KOÇARLI'),
(135, 'AYDIN', 'KÖŞK'),
(136, 'AYDIN', 'KUŞADASI'),
(137, 'AYDIN', 'KUYUCAK'),
(138, 'AYDIN', 'NAZİLLİ'),
(139, 'AYDIN', 'SÖKE'),
(140, 'AYDIN', 'SULTANHİSAR'),
(141, 'AYDIN', 'YENİPAZAR'),
(142, 'BALIKESİR', 'ALTIEYLÜL'),
(143, 'BALIKESİR', 'AYVALIK'),
(144, 'BALIKESİR', 'BALYA'),
(145, 'BALIKESİR', 'BANDIRMA'),
(146, 'BALIKESİR', 'BİGADİÇ'),
(147, 'BALIKESİR', 'BURHANİYE'),
(148, 'BALIKESİR', 'DURSUNBEY'),
(149, 'BALIKESİR', 'EDREMİT'),
(150, 'BALIKESİR', 'ERDEK'),
(151, 'BALIKESİR', 'GÖMEÇ'),
(152, 'BALIKESİR', 'GÖNEN'),
(153, 'BALIKESİR', 'HAVRAN'),
(154, 'BALIKESİR', 'İVRİNDİ'),
(155, 'BALIKESİR', 'KARESİ'),
(156, 'BALIKESİR', 'KEPSUT'),
(157, 'BALIKESİR', 'MANYAS'),
(158, 'BALIKESİR', 'MARMARA'),
(159, 'BALIKESİR', 'SAVAŞTEPE'),
(160, 'BALIKESİR', 'SINDIRGI'),
(161, 'BALIKESİR', 'SUSURLUK'),
(162, 'BARTIN', 'AMASRA'),
(163, 'BARTIN', 'KURUCAŞİLE'),
(164, 'BARTIN', 'MERKEZ'),
(165, 'BARTIN', 'ULUS'),
(166, 'BATMAN', 'BEŞİRİ'),
(167, 'BATMAN', 'GERCÜŞ'),
(168, 'BATMAN', 'HASANKEYF'),
(169, 'BATMAN', 'KOZLUK'),
(170, 'BATMAN', 'MERKEZ'),
(171, 'BATMAN', 'SASON'),
(172, 'BAYBURT', 'AYDINTEPE'),
(173, 'BAYBURT', 'DEMİRÖZÜ'),
(174, 'BAYBURT', 'MERKEZ'),
(175, 'BİLECİK', 'BOZÜYÜK'),
(176, 'BİLECİK', 'GÖLPAZARI'),
(177, 'BİLECİK', 'İNHİSAR'),
(178, 'BİLECİK', 'MERKEZ'),
(179, 'BİLECİK', 'OSMANELİ'),
(180, 'BİLECİK', 'PAZARYERİ'),
(181, 'BİLECİK', 'SÖĞÜT'),
(182, 'BİLECİK', 'YENİPAZAR'),
(183, 'BİNGÖL', 'ADAKLI'),
(184, 'BİNGÖL', 'GENÇ'),
(185, 'BİNGÖL', 'KARLIOVA'),
(186, 'BİNGÖL', 'KİĞI'),
(187, 'BİNGÖL', 'MERKEZ'),
(188, 'BİNGÖL', 'SOLHAN'),
(189, 'BİNGÖL', 'YAYLADERE'),
(190, 'BİNGÖL', 'YEDİSU'),
(191, 'BİTLİS', 'ADİLCEVAZ'),
(192, 'BİTLİS', 'AHLAT'),
(193, 'BİTLİS', 'GÜROYMAK'),
(194, 'BİTLİS', 'HİZAN'),
(195, 'BİTLİS', 'MERKEZ'),
(196, 'BİTLİS', 'MUTKİ'),
(197, 'BİTLİS', 'TATVAN'),
(198, 'BOLU', 'DÖRTDİVAN'),
(199, 'BOLU', 'GEREDE'),
(200, 'BOLU', 'GÖYNÜK'),
(201, 'BOLU', 'KIBRISCIK'),
(202, 'BOLU', 'MENGEN'),
(203, 'BOLU', 'MERKEZ'),
(204, 'BOLU', 'MUDURNU'),
(205, 'BOLU', 'SEBEN'),
(206, 'BOLU', 'YENİÇAĞA'),
(207, 'BURDUR', 'AĞLASUN'),
(208, 'BURDUR', 'ALTINYAYLA'),
(209, 'BURDUR', 'BUCAK'),
(210, 'BURDUR', 'ÇAVDIR'),
(211, 'BURDUR', 'ÇELTİKÇİ'),
(212, 'BURDUR', 'GÖLHİSAR'),
(213, 'BURDUR', 'KARAMANLI'),
(214, 'BURDUR', 'KEMER'),
(215, 'BURDUR', 'MERKEZ'),
(216, 'BURDUR', 'TEFENNİ'),
(217, 'BURDUR', 'YEŞİLOVA'),
(218, 'BURSA', 'BÜYÜKORHAN'),
(219, 'BURSA', 'GEMLİK'),
(220, 'BURSA', 'GÜRSU'),
(221, 'BURSA', 'HARMANCIK'),
(222, 'BURSA', 'İNEGÖL'),
(223, 'BURSA', 'İZNİK'),
(224, 'BURSA', 'KARACABEY'),
(225, 'BURSA', 'KELES'),
(226, 'BURSA', 'KESTEL'),
(227, 'BURSA', 'MUDANYA'),
(228, 'BURSA', 'MUSTAFAKEMALPAŞA'),
(229, 'BURSA', 'NİLÜFER'),
(230, 'BURSA', 'ORHANELİ'),
(231, 'BURSA', 'ORHANGAZİ'),
(232, 'BURSA', 'OSMANGAZİ'),
(233, 'BURSA', 'YENİŞEHİR'),
(234, 'BURSA', 'YILDIRIM'),
(235, 'ÇANAKKALE', 'AYVACIK'),
(236, 'ÇANAKKALE', 'BAYRAMİÇ'),
(237, 'ÇANAKKALE', 'BİGA'),
(238, 'ÇANAKKALE', 'BOZCAADA'),
(239, 'ÇANAKKALE', 'ÇAN'),
(240, 'ÇANAKKALE', 'ECEABAT'),
(241, 'ÇANAKKALE', 'EZİNE'),
(242, 'ÇANAKKALE', 'GELİBOLU'),
(243, 'ÇANAKKALE', 'GÖKÇEADA'),
(244, 'ÇANAKKALE', 'LAPSEKİ'),
(245, 'ÇANAKKALE', 'MERKEZ'),
(246, 'ÇANAKKALE', 'YENİCE'),
(247, 'ÇANKIRI', 'ATKARACALAR'),
(248, 'ÇANKIRI', 'BAYRAMÖREN'),
(249, 'ÇANKIRI', 'ÇERKEŞ'),
(250, 'ÇANKIRI', 'ELDİVAN'),
(251, 'ÇANKIRI', 'ILGAZ'),
(252, 'ÇANKIRI', 'KIZILIRMAK'),
(253, 'ÇANKIRI', 'KORGUN'),
(254, 'ÇANKIRI', 'KURŞUNLU'),
(255, 'ÇANKIRI', 'MERKEZ'),
(256, 'ÇANKIRI', 'ORTA'),
(257, 'ÇANKIRI', 'ŞABANÖZÜ'),
(258, 'ÇANKIRI', 'YAPRAKLI'),
(259, 'ÇORUM', 'ALACA'),
(260, 'ÇORUM', 'BAYAT'),
(261, 'ÇORUM', 'BOĞAZKALE'),
(262, 'ÇORUM', 'DODURGA'),
(263, 'ÇORUM', 'İSKİLİP'),
(264, 'ÇORUM', 'KARGI'),
(265, 'ÇORUM', 'LAÇİN'),
(266, 'ÇORUM', 'MECİTÖZÜ'),
(267, 'ÇORUM', 'MERKEZ'),
(268, 'ÇORUM', 'OĞUZLAR'),
(269, 'ÇORUM', 'ORTAKÖY'),
(270, 'ÇORUM', 'OSMANCIK'),
(271, 'ÇORUM', 'SUNGURLU'),
(272, 'ÇORUM', 'UĞURLUDAĞ'),
(273, 'DENİZLİ', 'ACIPAYAM'),
(274, 'DENİZLİ', 'BABADAĞ'),
(275, 'DENİZLİ', 'BAKLAN'),
(276, 'DENİZLİ', 'BEKİLLİ'),
(277, 'DENİZLİ', 'BEYAĞAÇ'),
(278, 'DENİZLİ', 'BOZKURT'),
(279, 'DENİZLİ', 'BULDAN'),
(280, 'DENİZLİ', 'ÇAL'),
(281, 'DENİZLİ', 'ÇAMELİ'),
(282, 'DENİZLİ', 'ÇARDAK'),
(283, 'DENİZLİ', 'ÇİVRİL'),
(284, 'DENİZLİ', 'GÜNEY'),
(285, 'DENİZLİ', 'HONAZ'),
(286, 'DENİZLİ', 'KALE'),
(287, 'DENİZLİ', 'MERKEZEFENDİ'),
(288, 'DENİZLİ', 'PAMUKKALE'),
(289, 'DENİZLİ', 'SARAYKÖY'),
(290, 'DENİZLİ', 'SERİNHİSAR'),
(291, 'DENİZLİ', 'TAVAS'),
(292, 'DİYARBAKIR', 'BAĞLAR'),
(293, 'DİYARBAKIR', 'BİSMİL'),
(294, 'DİYARBAKIR', 'ÇERMİK'),
(295, 'DİYARBAKIR', 'ÇINAR'),
(296, 'DİYARBAKIR', 'ÇÜNGÜŞ'),
(297, 'DİYARBAKIR', 'DİCLE'),
(298, 'DİYARBAKIR', 'EĞİL'),
(299, 'DİYARBAKIR', 'ERGANİ'),
(300, 'DİYARBAKIR', 'HANİ'),
(301, 'DİYARBAKIR', 'HAZRO'),
(302, 'DİYARBAKIR', 'KAYAPINAR'),
(303, 'DİYARBAKIR', 'KOCAKÖY'),
(304, 'DİYARBAKIR', 'KULP'),
(305, 'DİYARBAKIR', 'LİCE'),
(306, 'DİYARBAKIR', 'SİLVAN'),
(307, 'DİYARBAKIR', 'SUR'),
(308, 'DİYARBAKIR', 'YENİŞEHİR'),
(309, 'DÜZCE', 'AKÇAKOCA'),
(310, 'DÜZCE', 'CUMAYERİ'),
(311, 'DÜZCE', 'ÇİLİMLİ'),
(312, 'DÜZCE', 'GÖLYAKA'),
(313, 'DÜZCE', 'GÜMÜŞOVA'),
(314, 'DÜZCE', 'KAYNAŞLI'),
(315, 'DÜZCE', 'MERKEZ'),
(316, 'DÜZCE', 'YIĞILCA'),
(317, 'EDİRNE', 'ENEZ'),
(318, 'EDİRNE', 'HAVSA'),
(319, 'EDİRNE', 'İPSALA'),
(320, 'EDİRNE', 'KEŞAN'),
(321, 'EDİRNE', 'LALAPAŞA'),
(322, 'EDİRNE', 'MERİÇ'),
(323, 'EDİRNE', 'MERKEZ'),
(324, 'EDİRNE', 'SÜLOĞLU'),
(325, 'EDİRNE', 'UZUNKÖPRÜ'),
(326, 'ELAZIĞ', 'AĞIN'),
(327, 'ELAZIĞ', 'ALACAKAYA'),
(328, 'ELAZIĞ', 'ARICAK'),
(329, 'ELAZIĞ', 'BASKİL'),
(330, 'ELAZIĞ', 'KARAKOÇAN'),
(331, 'ELAZIĞ', 'KEBAN'),
(332, 'ELAZIĞ', 'KOVANCILAR'),
(333, 'ELAZIĞ', 'MADEN'),
(334, 'ELAZIĞ', 'MERKEZ'),
(335, 'ELAZIĞ', 'PALU'),
(336, 'ELAZIĞ', 'SİVRİCE'),
(337, 'ERZİNCAN', 'ÇAYIRLI'),
(338, 'ERZİNCAN', 'İLİÇ'),
(339, 'ERZİNCAN', 'KEMAH'),
(340, 'ERZİNCAN', 'KEMALİYE'),
(341, 'ERZİNCAN', 'MERKEZ'),
(342, 'ERZİNCAN', 'OTLUKBELİ'),
(343, 'ERZİNCAN', 'REFAHİYE'),
(344, 'ERZİNCAN', 'TERCAN'),
(345, 'ERZİNCAN', 'ÜZÜMLÜ'),
(346, 'ERZURUM', 'AŞKALE'),
(347, 'ERZURUM', 'AZİZİYE'),
(348, 'ERZURUM', 'ÇAT'),
(349, 'ERZURUM', 'HINIS'),
(350, 'ERZURUM', 'HORASAN'),
(351, 'ERZURUM', 'İSPİR'),
(352, 'ERZURUM', 'KARAÇOBAN'),
(353, 'ERZURUM', 'KARAYAZI'),
(354, 'ERZURUM', 'KÖPRÜKÖY'),
(355, 'ERZURUM', 'NARMAN'),
(356, 'ERZURUM', 'OLTU'),
(357, 'ERZURUM', 'OLUR'),
(358, 'ERZURUM', 'PALANDÖKEN'),
(359, 'ERZURUM', 'PASİNLER'),
(360, 'ERZURUM', 'PAZARYOLU'),
(361, 'ERZURUM', 'ŞENKAYA'),
(362, 'ERZURUM', 'TEKMAN'),
(363, 'ERZURUM', 'TORTUM'),
(364, 'ERZURUM', 'UZUNDERE'),
(365, 'ERZURUM', 'YAKUTİYE'),
(366, 'ESKİŞEHİR', 'ALPU'),
(367, 'ESKİŞEHİR', 'BEYLİKOVA'),
(368, 'ESKİŞEHİR', 'ÇİFTELER'),
(369, 'ESKİŞEHİR', 'GÜNYÜZÜ'),
(370, 'ESKİŞEHİR', 'HAN'),
(371, 'ESKİŞEHİR', 'İNÖNÜ'),
(372, 'ESKİŞEHİR', 'MAHMUDİYE'),
(373, 'ESKİŞEHİR', 'MİHALGAZİ'),
(374, 'ESKİŞEHİR', 'MİHALIÇÇIK'),
(375, 'ESKİŞEHİR', 'ODUNPAZARI'),
(376, 'ESKİŞEHİR', 'SARICAKAYA'),
(377, 'ESKİŞEHİR', 'SEYİTGAZİ'),
(378, 'ESKİŞEHİR', 'SİVRİHİSAR'),
(379, 'ESKİŞEHİR', 'TEPEBAŞI'),
(380, 'GAZİANTEP', 'ARABAN'),
(381, 'GAZİANTEP', 'İSLAHİYE'),
(382, 'GAZİANTEP', 'KARKAMIŞ'),
(383, 'GAZİANTEP', 'NİZİP'),
(384, 'GAZİANTEP', 'NURDAĞI'),
(385, 'GAZİANTEP', 'OĞUZELİ'),
(386, 'GAZİANTEP', 'ŞAHİNBEY'),
(387, 'GAZİANTEP', 'ŞEHİTKAMİL'),
(388, 'GAZİANTEP', 'YAVUZELİ'),
(389, 'GİRESUN', 'ALUCRA'),
(390, 'GİRESUN', 'BULANCAK'),
(391, 'GİRESUN', 'ÇAMOLUK'),
(392, 'GİRESUN', 'ÇANAKÇI'),
(393, 'GİRESUN', 'DERELİ'),
(394, 'GİRESUN', 'DOĞANKENT'),
(395, 'GİRESUN', 'ESPİYE'),
(396, 'GİRESUN', 'EYNESİL'),
(397, 'GİRESUN', 'GÖRELE'),
(398, 'GİRESUN', 'GÜCE'),
(399, 'GİRESUN', 'KEŞAP'),
(400, 'GİRESUN', 'MERKEZ'),
(401, 'GİRESUN', 'PİRAZİZ'),
(402, 'GİRESUN', 'ŞEBİNKARAHİSAR'),
(403, 'GİRESUN', 'TİREBOLU'),
(404, 'GİRESUN', 'YAĞLIDERE'),
(405, 'GÜMÜŞHANE', 'KELKİT'),
(406, 'GÜMÜŞHANE', 'KÖSE'),
(407, 'GÜMÜŞHANE', 'KÜRTÜN'),
(408, 'GÜMÜŞHANE', 'MERKEZ'),
(409, 'GÜMÜŞHANE', 'ŞİRAN'),
(410, 'GÜMÜŞHANE', 'TORUL'),
(411, 'HAKKARİ', 'ÇUKURCA'),
(412, 'HAKKARİ', 'DERECİK'),
(413, 'HAKKARİ', 'MERKEZ'),
(414, 'HAKKARİ', 'ŞEMDİNLİ'),
(415, 'HAKKARİ', 'YÜKSEKOVA'),
(416, 'HATAY', 'ALTINÖZÜ'),
(417, 'HATAY', 'ANTAKYA'),
(418, 'HATAY', 'ARSUZ'),
(419, 'HATAY', 'BELEN'),
(420, 'HATAY', 'DEFNE'),
(421, 'HATAY', 'DÖRTYOL'),
(422, 'HATAY', 'ERZİN'),
(423, 'HATAY', 'HASSA'),
(424, 'HATAY', 'İSKENDERUN'),
(425, 'HATAY', 'KIRIKHAN'),
(426, 'HATAY', 'KUMLU'),
(427, 'HATAY', 'PAYAS'),
(428, 'HATAY', 'REYHANLI'),
(429, 'HATAY', 'SAMANDAĞ'),
(430, 'HATAY', 'YAYLADAĞI'),
(431, 'IĞDIR', 'ARALIK'),
(432, 'IĞDIR', 'KARAKOYUNLU'),
(433, 'IĞDIR', 'MERKEZ'),
(434, 'IĞDIR', 'TUZLUCA'),
(435, 'ISPARTA', 'AKSU'),
(436, 'ISPARTA', 'ATABEY'),
(437, 'ISPARTA', 'EĞİRDİR'),
(438, 'ISPARTA', 'GELENDOST'),
(439, 'ISPARTA', 'GÖNEN'),
(440, 'ISPARTA', 'KEÇİBORLU'),
(441, 'ISPARTA', 'MERKEZ'),
(442, 'ISPARTA', 'SENİRKENT'),
(443, 'ISPARTA', 'SÜTÇÜLER'),
(444, 'ISPARTA', 'ŞARKİKARAAĞAÇ'),
(445, 'ISPARTA', 'ULUBORLU'),
(446, 'ISPARTA', 'YALVAÇ'),
(447, 'ISPARTA', 'YENİŞARBADEMLİ'),
(448, 'İSTANBUL', 'ADALAR'),
(449, 'İSTANBUL', 'ARNAVUTKÖY'),
(450, 'İSTANBUL', 'ATAŞEHİR'),
(451, 'İSTANBUL', 'AVCILAR'),
(452, 'İSTANBUL', 'BAĞCILAR'),
(453, 'İSTANBUL', 'BAHÇELİEVLER'),
(454, 'İSTANBUL', 'BAKIRKÖY'),
(455, 'İSTANBUL', 'BAŞAKŞEHİR'),
(456, 'İSTANBUL', 'BAYRAMPAŞA'),
(457, 'İSTANBUL', 'BEŞİKTAŞ'),
(458, 'İSTANBUL', 'BEYKOZ'),
(459, 'İSTANBUL', 'BEYLİKDÜZÜ'),
(460, 'İSTANBUL', 'BEYOĞLU'),
(461, 'İSTANBUL', 'BÜYÜKÇEKMECE'),
(462, 'İSTANBUL', 'ÇATALCA'),
(463, 'İSTANBUL', 'ÇEKMEKÖY'),
(464, 'İSTANBUL', 'ESENLER'),
(465, 'İSTANBUL', 'ESENYURT'),
(466, 'İSTANBUL', 'EYÜPSULTAN'),
(467, 'İSTANBUL', 'FATİH'),
(468, 'İSTANBUL', 'GAZİOSMANPAŞA'),
(469, 'İSTANBUL', 'GÜNGÖREN'),
(470, 'İSTANBUL', 'KADIKÖY'),
(471, 'İSTANBUL', 'KAĞITHANE'),
(472, 'İSTANBUL', 'KARTAL'),
(473, 'İSTANBUL', 'KÜÇÜKÇEKMECE'),
(474, 'İSTANBUL', 'MALTEPE'),
(475, 'İSTANBUL', 'PENDİK'),
(476, 'İSTANBUL', 'SANCAKTEPE'),
(477, 'İSTANBUL', 'SARIYER'),
(478, 'İSTANBUL', 'SİLİVRİ'),
(479, 'İSTANBUL', 'SULTANBEYLİ'),
(480, 'İSTANBUL', 'SULTANGAZİ'),
(481, 'İSTANBUL', 'ŞİLE'),
(482, 'İSTANBUL', 'ŞİŞLİ'),
(483, 'İSTANBUL', 'TUZLA'),
(484, 'İSTANBUL', 'ÜMRANİYE'),
(485, 'İSTANBUL', 'ÜSKÜDAR'),
(486, 'İSTANBUL', 'ZEYTİNBURNU'),
(487, 'İZMİR', 'ALİAĞA'),
(488, 'İZMİR', 'BALÇOVA'),
(489, 'İZMİR', 'BAYINDIR'),
(490, 'İZMİR', 'BAYRAKLI'),
(491, 'İZMİR', 'BERGAMA'),
(492, 'İZMİR', 'BEYDAĞ'),
(493, 'İZMİR', 'BORNOVA'),
(494, 'İZMİR', 'BUCA'),
(495, 'İZMİR', 'ÇEŞME'),
(496, 'İZMİR', 'ÇİĞLİ'),
(497, 'İZMİR', 'DİKİLİ'),
(498, 'İZMİR', 'FOÇA'),
(499, 'İZMİR', 'GAZİEMİR'),
(500, 'İZMİR', 'GÜZELBAHÇE'),
(501, 'İZMİR', 'KARABAĞLAR'),
(502, 'İZMİR', 'KARABURUN'),
(503, 'İZMİR', 'KARŞIYAKA'),
(504, 'İZMİR', 'KEMALPAŞA'),
(505, 'İZMİR', 'KINIK'),
(506, 'İZMİR', 'KİRAZ'),
(507, 'İZMİR', 'KONAK'),
(508, 'İZMİR', 'MENDERES'),
(509, 'İZMİR', 'MENEMEN'),
(510, 'İZMİR', 'NARLIDERE'),
(511, 'İZMİR', 'ÖDEMİŞ'),
(512, 'İZMİR', 'SEFERİHİSAR'),
(513, 'İZMİR', 'SELÇUK'),
(514, 'İZMİR', 'TİRE'),
(515, 'İZMİR', 'TORBALI'),
(516, 'İZMİR', 'URLA'),
(517, 'KAHRAMANMARAŞ', 'AFŞİN'),
(518, 'KAHRAMANMARAŞ', 'ANDIRIN'),
(519, 'KAHRAMANMARAŞ', 'ÇAĞLAYANCERİT'),
(520, 'KAHRAMANMARAŞ', 'DULKADİROĞLU'),
(521, 'KAHRAMANMARAŞ', 'EKİNÖZÜ'),
(522, 'KAHRAMANMARAŞ', 'ELBİSTAN'),
(523, 'KAHRAMANMARAŞ', 'GÖKSUN'),
(524, 'KAHRAMANMARAŞ', 'NURHAK'),
(525, 'KAHRAMANMARAŞ', 'ONİKİŞUBAT'),
(526, 'KAHRAMANMARAŞ', 'PAZARCIK'),
(527, 'KAHRAMANMARAŞ', 'TÜRKOĞLU'),
(528, 'KARABÜK', 'EFLANİ'),
(529, 'KARABÜK', 'ESKİPAZAR'),
(530, 'KARABÜK', 'MERKEZ'),
(531, 'KARABÜK', 'OVACIK'),
(532, 'KARABÜK', 'SAFRANBOLU'),
(533, 'KARABÜK', 'YENİCE'),
(534, 'KARAMAN', 'AYRANCI'),
(535, 'KARAMAN', 'BAŞYAYLA'),
(536, 'KARAMAN', 'ERMENEK'),
(537, 'KARAMAN', 'KAZIMKARABEKİR'),
(538, 'KARAMAN', 'MERKEZ'),
(539, 'KARAMAN', 'SARIVELİLER'),
(540, 'KARS', 'AKYAKA'),
(541, 'KARS', 'ARPAÇAY'),
(542, 'KARS', 'DİGOR'),
(543, 'KARS', 'KAĞIZMAN'),
(544, 'KARS', 'MERKEZ'),
(545, 'KARS', 'SARIKAMIŞ'),
(546, 'KARS', 'SELİM'),
(547, 'KARS', 'SUSUZ'),
(548, 'KASTAMONU', 'ABANA'),
(549, 'KASTAMONU', 'AĞLI'),
(550, 'KASTAMONU', 'ARAÇ'),
(551, 'KASTAMONU', 'AZDAVAY'),
(552, 'KASTAMONU', 'BOZKURT'),
(553, 'KASTAMONU', 'CİDE'),
(554, 'KASTAMONU', 'ÇATALZEYTİN'),
(555, 'KASTAMONU', 'DADAY'),
(556, 'KASTAMONU', 'DEVREKANİ'),
(557, 'KASTAMONU', 'DOĞANYURT'),
(558, 'KASTAMONU', 'HANÖNÜ'),
(559, 'KASTAMONU', 'İHSANGAZİ'),
(560, 'KASTAMONU', 'İNEBOLU'),
(561, 'KASTAMONU', 'KÜRE'),
(562, 'KASTAMONU', 'MERKEZ'),
(563, 'KASTAMONU', 'PINARBAŞI'),
(564, 'KASTAMONU', 'SEYDİLER'),
(565, 'KASTAMONU', 'ŞENPAZAR'),
(566, 'KASTAMONU', 'TAŞKÖPRÜ'),
(567, 'KASTAMONU', 'TOSYA'),
(568, 'KAYSERİ', 'AKKIŞLA'),
(569, 'KAYSERİ', 'BÜNYAN'),
(570, 'KAYSERİ', 'DEVELİ'),
(571, 'KAYSERİ', 'FELAHİYE'),
(572, 'KAYSERİ', 'HACILAR'),
(573, 'KAYSERİ', 'İNCESU'),
(574, 'KAYSERİ', 'KOCASİNAN'),
(575, 'KAYSERİ', 'MELİKGAZİ'),
(576, 'KAYSERİ', 'ÖZVATAN'),
(577, 'KAYSERİ', 'PINARBAŞI'),
(578, 'KAYSERİ', 'SARIOĞLAN'),
(579, 'KAYSERİ', 'SARIZ'),
(580, 'KAYSERİ', 'TALAS'),
(581, 'KAYSERİ', 'TOMARZA'),
(582, 'KAYSERİ', 'YAHYALI'),
(583, 'KAYSERİ', 'YEŞİLHİSAR'),
(584, 'KIRIKKALE', 'BAHŞILI'),
(585, 'KIRIKKALE', 'BALIŞEYH'),
(586, 'KIRIKKALE', 'ÇELEBİ'),
(587, 'KIRIKKALE', 'DELİCE'),
(588, 'KIRIKKALE', 'KARAKEÇİLİ'),
(589, 'KIRIKKALE', 'KESKİN'),
(590, 'KIRIKKALE', 'MERKEZ'),
(591, 'KIRIKKALE', 'SULAKYURT'),
(592, 'KIRIKKALE', 'YAHŞİHAN'),
(593, 'KIRKLARELİ', 'BABAESKİ'),
(594, 'KIRKLARELİ', 'DEMİRKÖY'),
(595, 'KIRKLARELİ', 'KOFÇAZ'),
(596, 'KIRKLARELİ', 'LÜLEBURGAZ'),
(597, 'KIRKLARELİ', 'MERKEZ'),
(598, 'KIRKLARELİ', 'PEHLİVANKÖY'),
(599, 'KIRKLARELİ', 'PINARHİSAR'),
(600, 'KIRKLARELİ', 'VİZE'),
(601, 'KIRŞEHİR', 'AKÇAKENT'),
(602, 'KIRŞEHİR', 'AKPINAR'),
(603, 'KIRŞEHİR', 'BOZTEPE'),
(604, 'KIRŞEHİR', 'ÇİÇEKDAĞI'),
(605, 'KIRŞEHİR', 'KAMAN'),
(606, 'KIRŞEHİR', 'MERKEZ'),
(607, 'KIRŞEHİR', 'MUCUR'),
(608, 'KİLİS', 'ELBEYLİ'),
(609, 'KİLİS', 'MERKEZ'),
(610, 'KİLİS', 'MUSABEYLİ'),
(611, 'KİLİS', 'POLATELİ'),
(612, 'KOCAELİ', 'BAŞİSKELE'),
(613, 'KOCAELİ', 'ÇAYIROVA'),
(614, 'KOCAELİ', 'DARICA'),
(615, 'KOCAELİ', 'DERİNCE'),
(616, 'KOCAELİ', 'DİLOVASI'),
(617, 'KOCAELİ', 'GEBZE'),
(618, 'KOCAELİ', 'GÖLCÜK'),
(619, 'KOCAELİ', 'İZMİT'),
(620, 'KOCAELİ', 'KANDIRA'),
(621, 'KOCAELİ', 'KARAMÜRSEL'),
(622, 'KOCAELİ', 'KARTEPE'),
(623, 'KOCAELİ', 'KÖRFEZ'),
(624, 'KONYA', 'AHIRLI'),
(625, 'KONYA', 'AKÖREN'),
(626, 'KONYA', 'AKŞEHİR'),
(627, 'KONYA', 'ALTINEKİN'),
(628, 'KONYA', 'BEYŞEHİR'),
(629, 'KONYA', 'BOZKIR'),
(630, 'KONYA', 'CİHANBEYLİ'),
(631, 'KONYA', 'ÇELTİK'),
(632, 'KONYA', 'ÇUMRA'),
(633, 'KONYA', 'DERBENT'),
(634, 'KONYA', 'DEREBUCAK'),
(635, 'KONYA', 'DOĞANHİSAR'),
(636, 'KONYA', 'EMİRGAZİ'),
(637, 'KONYA', 'EREĞLİ'),
(638, 'KONYA', 'GÜNEYSINIR'),
(639, 'KONYA', 'HADİM'),
(640, 'KONYA', 'HALKAPINAR'),
(641, 'KONYA', 'HÜYÜK'),
(642, 'KONYA', 'ILGIN'),
(643, 'KONYA', 'KADINHANI'),
(644, 'KONYA', 'KARAPINAR'),
(645, 'KONYA', 'KARATAY'),
(646, 'KONYA', 'KULU'),
(647, 'KONYA', 'MERAM'),
(648, 'KONYA', 'SARAYÖNÜ'),
(649, 'KONYA', 'SELÇUKLU'),
(650, 'KONYA', 'SEYDİŞEHİR'),
(651, 'KONYA', 'TAŞKENT'),
(652, 'KONYA', 'TUZLUKÇU'),
(653, 'KONYA', 'YALIHÜYÜK'),
(654, 'KONYA', 'YUNAK'),
(655, 'KÜTAHYA', 'ALTINTAŞ'),
(656, 'KÜTAHYA', 'ASLANAPA'),
(657, 'KÜTAHYA', 'ÇAVDARHİSAR'),
(658, 'KÜTAHYA', 'DOMANİÇ'),
(659, 'KÜTAHYA', 'DUMLUPINAR'),
(660, 'KÜTAHYA', 'EMET'),
(661, 'KÜTAHYA', 'GEDİZ'),
(662, 'KÜTAHYA', 'HİSARCIK'),
(663, 'KÜTAHYA', 'MERKEZ'),
(664, 'KÜTAHYA', 'PAZARLAR'),
(665, 'KÜTAHYA', 'SİMAV'),
(666, 'KÜTAHYA', 'ŞAPHANE'),
(667, 'KÜTAHYA', 'TAVŞANLI'),
(668, 'MALATYA', 'AKÇADAĞ'),
(669, 'MALATYA', 'ARAPGİR'),
(670, 'MALATYA', 'ARGUVAN'),
(671, 'MALATYA', 'BATTALGAZİ'),
(672, 'MALATYA', 'DARENDE'),
(673, 'MALATYA', 'DOĞANŞEHİR'),
(674, 'MALATYA', 'DOĞANYOL'),
(675, 'MALATYA', 'HEKİMHAN'),
(676, 'MALATYA', 'KALE'),
(677, 'MALATYA', 'KULUNCAK'),
(678, 'MALATYA', 'PÜTÜRGE'),
(679, 'MALATYA', 'YAZIHAN'),
(680, 'MALATYA', 'YEŞİLYURT'),
(681, 'MANİSA', 'AHMETLİ'),
(682, 'MANİSA', 'AKHİSAR'),
(683, 'MANİSA', 'ALAŞEHİR'),
(684, 'MANİSA', 'DEMİRCİ'),
(685, 'MANİSA', 'GÖLMARMARA'),
(686, 'MANİSA', 'GÖRDES'),
(687, 'MANİSA', 'KIRKAĞAÇ'),
(688, 'MANİSA', 'KÖPRÜBAŞI'),
(689, 'MANİSA', 'KULA'),
(690, 'MANİSA', 'SALİHLİ'),
(691, 'MANİSA', 'SARIGÖL'),
(692, 'MANİSA', 'SARUHANLI'),
(693, 'MANİSA', 'SELENDİ'),
(694, 'MANİSA', 'SOMA'),
(695, 'MANİSA', 'ŞEHZADELER'),
(696, 'MANİSA', 'TURGUTLU'),
(697, 'MANİSA', 'YUNUSEMRE'),
(698, 'MARDİN', 'ARTUKLU'),
(699, 'MARDİN', 'DARGEÇİT'),
(700, 'MARDİN', 'DERİK'),
(701, 'MARDİN', 'KIZILTEPE'),
(702, 'MARDİN', 'MAZIDAĞI'),
(703, 'MARDİN', 'MİDYAT'),
(704, 'MARDİN', 'NUSAYBİN'),
(705, 'MARDİN', 'ÖMERLİ'),
(706, 'MARDİN', 'SAVUR'),
(707, 'MARDİN', 'YEŞİLLİ'),
(708, 'MERSİN', 'AKDENİZ'),
(709, 'MERSİN', 'ANAMUR'),
(710, 'MERSİN', 'AYDINCIK'),
(711, 'MERSİN', 'BOZYAZI'),
(712, 'MERSİN', 'ÇAMLIYAYLA'),
(713, 'MERSİN', 'ERDEMLİ'),
(714, 'MERSİN', 'GÜLNAR'),
(715, 'MERSİN', 'MEZİTLİ'),
(716, 'MERSİN', 'MUT'),
(717, 'MERSİN', 'SİLİFKE'),
(718, 'MERSİN', 'TARSUS'),
(719, 'MERSİN', 'TOROSLAR'),
(720, 'MERSİN', 'YENİŞEHİR'),
(721, 'MUĞLA', 'BODRUM'),
(722, 'MUĞLA', 'DALAMAN'),
(723, 'MUĞLA', 'DATÇA'),
(724, 'MUĞLA', 'FETHİYE'),
(725, 'MUĞLA', 'KAVAKLIDERE'),
(726, 'MUĞLA', 'KÖYCEĞİZ'),
(727, 'MUĞLA', 'MARMARİS'),
(728, 'MUĞLA', 'MENTEŞE'),
(729, 'MUĞLA', 'MİLAS'),
(730, 'MUĞLA', 'ORTACA'),
(731, 'MUĞLA', 'SEYDİKEMER'),
(732, 'MUĞLA', 'ULA'),
(733, 'MUĞLA', 'YATAĞAN'),
(734, 'MUŞ', 'BULANIK'),
(735, 'MUŞ', 'HASKÖY'),
(736, 'MUŞ', 'KORKUT'),
(737, 'MUŞ', 'MALAZGİRT'),
(738, 'MUŞ', 'MERKEZ'),
(739, 'MUŞ', 'VARTO'),
(740, 'NEVŞEHİR', 'ACIGÖL'),
(741, 'NEVŞEHİR', 'AVANOS'),
(742, 'NEVŞEHİR', 'DERİNKUYU'),
(743, 'NEVŞEHİR', 'GÜLŞEHİR'),
(744, 'NEVŞEHİR', 'HACIBEKTAŞ'),
(745, 'NEVŞEHİR', 'KOZAKLI'),
(746, 'NEVŞEHİR', 'MERKEZ'),
(747, 'NEVŞEHİR', 'ÜRGÜP'),
(748, 'NİĞDE', 'ALTUNHİSAR'),
(749, 'NİĞDE', 'BOR'),
(750, 'NİĞDE', 'ÇAMARDI'),
(751, 'NİĞDE', 'ÇİFTLİK'),
(752, 'NİĞDE', 'MERKEZ'),
(753, 'NİĞDE', 'ULUKIŞLA'),
(754, 'ORDU', 'AKKUŞ'),
(755, 'ORDU', 'ALTINORDU'),
(756, 'ORDU', 'AYBASTI'),
(757, 'ORDU', 'ÇAMAŞ'),
(758, 'ORDU', 'ÇATALPINAR'),
(759, 'ORDU', 'ÇAYBAŞI'),
(760, 'ORDU', 'FATSA'),
(761, 'ORDU', 'GÖLKÖY'),
(762, 'ORDU', 'GÜLYALI'),
(763, 'ORDU', 'GÜRGENTEPE'),
(764, 'ORDU', 'İKİZCE'),
(765, 'ORDU', 'KABADÜZ'),
(766, 'ORDU', 'KABATAŞ'),
(767, 'ORDU', 'KORGAN'),
(768, 'ORDU', 'KUMRU'),
(769, 'ORDU', 'MESUDİYE'),
(770, 'ORDU', 'PERŞEMBE'),
(771, 'ORDU', 'ULUBEY'),
(772, 'ORDU', 'ÜNYE'),
(773, 'OSMANİYE', 'BAHÇE'),
(774, 'OSMANİYE', 'DÜZİÇİ'),
(775, 'OSMANİYE', 'HASANBEYLİ'),
(776, 'OSMANİYE', 'KADİRLİ'),
(777, 'OSMANİYE', 'MERKEZ'),
(778, 'OSMANİYE', 'SUMBAS'),
(779, 'OSMANİYE', 'TOPRAKKALE'),
(780, 'RİZE', 'ARDEŞEN'),
(781, 'RİZE', 'ÇAMLIHEMŞİN'),
(782, 'RİZE', 'ÇAYELİ'),
(783, 'RİZE', 'DEREPAZARI'),
(784, 'RİZE', 'FINDIKLI'),
(785, 'RİZE', 'GÜNEYSU'),
(786, 'RİZE', 'HEMŞİN'),
(787, 'RİZE', 'İKİZDERE'),
(788, 'RİZE', 'İYİDERE'),
(789, 'RİZE', 'KALKANDERE'),
(790, 'RİZE', 'MERKEZ'),
(791, 'RİZE', 'PAZAR'),
(792, 'SAKARYA', 'ADAPAZARI'),
(793, 'SAKARYA', 'AKYAZI'),
(794, 'SAKARYA', 'ARİFİYE'),
(795, 'SAKARYA', 'ERENLER'),
(796, 'SAKARYA', 'FERİZLİ'),
(797, 'SAKARYA', 'GEYVE'),
(798, 'SAKARYA', 'HENDEK'),
(799, 'SAKARYA', 'KARAPÜRÇEK'),
(800, 'SAKARYA', 'KARASU'),
(801, 'SAKARYA', 'KAYNARCA'),
(802, 'SAKARYA', 'KOCAALİ'),
(803, 'SAKARYA', 'PAMUKOVA'),
(804, 'SAKARYA', 'SAPANCA'),
(805, 'SAKARYA', 'SERDİVAN'),
(806, 'SAKARYA', 'SÖĞÜTLÜ'),
(807, 'SAKARYA', 'TARAKLI'),
(808, 'SAMSUN', '19 MAYIS'),
(809, 'SAMSUN', 'ALAÇAM'),
(810, 'SAMSUN', 'ASARCIK'),
(811, 'SAMSUN', 'ATAKUM'),
(812, 'SAMSUN', 'AYVACIK'),
(813, 'SAMSUN', 'BAFRA'),
(814, 'SAMSUN', 'CANİK'),
(815, 'SAMSUN', 'ÇARŞAMBA'),
(816, 'SAMSUN', 'HAVZA'),
(817, 'SAMSUN', 'İLKADIM'),
(818, 'SAMSUN', 'KAVAK'),
(819, 'SAMSUN', 'LADİK'),
(820, 'SAMSUN', 'SALIPAZARI'),
(821, 'SAMSUN', 'TEKKEKÖY'),
(822, 'SAMSUN', 'TERME'),
(823, 'SAMSUN', 'VEZİRKÖPRÜ'),
(824, 'SAMSUN', 'YAKAKENT'),
(825, 'SİİRT', 'BAYKAN'),
(826, 'SİİRT', 'ERUH'),
(827, 'SİİRT', 'KURTALAN'),
(828, 'SİİRT', 'MERKEZ'),
(829, 'SİİRT', 'PERVARİ'),
(830, 'SİİRT', 'ŞİRVAN'),
(831, 'SİİRT', 'TİLLO'),
(832, 'SİNOP', 'AYANCIK'),
(833, 'SİNOP', 'BOYABAT'),
(834, 'SİNOP', 'DİKMEN'),
(835, 'SİNOP', 'DURAĞAN'),
(836, 'SİNOP', 'ERFELEK'),
(837, 'SİNOP', 'GERZE'),
(838, 'SİNOP', 'MERKEZ'),
(839, 'SİNOP', 'SARAYDÜZÜ'),
(840, 'SİNOP', 'TÜRKELİ'),
(841, 'SİVAS', 'AKINCILAR'),
(842, 'SİVAS', 'ALTINYAYLA'),
(843, 'SİVAS', 'DİVRİĞİ'),
(844, 'SİVAS', 'DOĞANŞAR'),
(845, 'SİVAS', 'GEMEREK'),
(846, 'SİVAS', 'GÖLOVA'),
(847, 'SİVAS', 'GÜRÜN'),
(848, 'SİVAS', 'HAFİK'),
(849, 'SİVAS', 'İMRANLI'),
(850, 'SİVAS', 'KANGAL'),
(851, 'SİVAS', 'KOYULHİSAR'),
(852, 'SİVAS', 'MERKEZ'),
(853, 'SİVAS', 'SUŞEHRİ'),
(854, 'SİVAS', 'ŞARKIŞLA'),
(855, 'SİVAS', 'ULAŞ'),
(856, 'SİVAS', 'YILDIZELİ'),
(857, 'SİVAS', 'ZARA'),
(858, 'ŞANLIURFA', 'AKÇAKALE'),
(859, 'ŞANLIURFA', 'BİRECİK'),
(860, 'ŞANLIURFA', 'BOZOVA'),
(861, 'ŞANLIURFA', 'CEYLANPINAR'),
(862, 'ŞANLIURFA', 'EYYÜBİYE'),
(863, 'ŞANLIURFA', 'HALFETİ'),
(864, 'ŞANLIURFA', 'HALİLİYE'),
(865, 'ŞANLIURFA', 'HARRAN'),
(866, 'ŞANLIURFA', 'HİLVAN'),
(867, 'ŞANLIURFA', 'KARAKÖPRÜ'),
(868, 'ŞANLIURFA', 'SİVEREK'),
(869, 'ŞANLIURFA', 'SURUÇ'),
(870, 'ŞANLIURFA', 'VİRANŞEHİR'),
(871, 'ŞIRNAK', 'BEYTÜŞŞEBAP'),
(872, 'ŞIRNAK', 'CİZRE'),
(873, 'ŞIRNAK', 'GÜÇLÜKONAK'),
(874, 'ŞIRNAK', 'İDİL'),
(875, 'ŞIRNAK', 'MERKEZ'),
(876, 'ŞIRNAK', 'SİLOPİ'),
(877, 'ŞIRNAK', 'ULUDERE'),
(878, 'TEKİRDAĞ', 'ÇERKEZKÖY'),
(879, 'TEKİRDAĞ', 'ÇORLU'),
(880, 'TEKİRDAĞ', 'ERGENE'),
(881, 'TEKİRDAĞ', 'HAYRABOLU'),
(882, 'TEKİRDAĞ', 'KAPAKLI'),
(883, 'TEKİRDAĞ', 'MALKARA'),
(884, 'TEKİRDAĞ', 'MARMARAEREĞLİSİ'),
(885, 'TEKİRDAĞ', 'MURATLI'),
(886, 'TEKİRDAĞ', 'SARAY'),
(887, 'TEKİRDAĞ', 'SÜLEYMANPAŞA'),
(888, 'TEKİRDAĞ', 'ŞARKÖY'),
(889, 'TOKAT', 'ALMUS'),
(890, 'TOKAT', 'ARTOVA'),
(891, 'TOKAT', 'BAŞÇİFTLİK'),
(892, 'TOKAT', 'ERBAA'),
(893, 'TOKAT', 'MERKEZ'),
(894, 'TOKAT', 'NİKSAR'),
(895, 'TOKAT', 'PAZAR'),
(896, 'TOKAT', 'REŞADİYE'),
(897, 'TOKAT', 'SULUSARAY'),
(898, 'TOKAT', 'TURHAL'),
(899, 'TOKAT', 'YEŞİLYURT'),
(900, 'TOKAT', 'ZİLE'),
(901, 'TRABZON', 'AKÇAABAT'),
(902, 'TRABZON', 'ARAKLI'),
(903, 'TRABZON', 'ARSİN'),
(904, 'TRABZON', 'BEŞİKDÜZÜ'),
(905, 'TRABZON', 'ÇARŞIBAŞI'),
(906, 'TRABZON', 'ÇAYKARA'),
(907, 'TRABZON', 'DERNEKPAZARI'),
(908, 'TRABZON', 'DÜZKÖY'),
(909, 'TRABZON', 'HAYRAT'),
(910, 'TRABZON', 'KÖPRÜBAŞI'),
(911, 'TRABZON', 'MAÇKA'),
(912, 'TRABZON', 'OF'),
(913, 'TRABZON', 'ORTAHİSAR'),
(914, 'TRABZON', 'SÜRMENE'),
(915, 'TRABZON', 'ŞALPAZARI'),
(916, 'TRABZON', 'TONYA'),
(917, 'TRABZON', 'VAKFIKEBİR'),
(918, 'TRABZON', 'YOMRA'),
(919, 'TUNCELİ', 'ÇEMİŞGEZEK'),
(920, 'TUNCELİ', 'HOZAT'),
(921, 'TUNCELİ', 'MAZGİRT'),
(922, 'TUNCELİ', 'MERKEZ'),
(923, 'TUNCELİ', 'NAZIMİYE'),
(924, 'TUNCELİ', 'OVACIK'),
(925, 'TUNCELİ', 'PERTEK'),
(926, 'TUNCELİ', 'PÜLÜMÜR'),
(927, 'UŞAK', 'BANAZ'),
(928, 'UŞAK', 'EŞME'),
(929, 'UŞAK', 'KARAHALLI'),
(930, 'UŞAK', 'MERKEZ'),
(931, 'UŞAK', 'SİVASLI'),
(932, 'UŞAK', 'ULUBEY'),
(933, 'VAN', 'BAHÇESARAY'),
(934, 'VAN', 'BAŞKALE'),
(935, 'VAN', 'ÇALDIRAN'),
(936, 'VAN', 'ÇATAK'),
(937, 'VAN', 'EDREMİT'),
(938, 'VAN', 'ERCİŞ'),
(939, 'VAN', 'GEVAŞ'),
(940, 'VAN', 'GÜRPINAR'),
(941, 'VAN', 'İPEKYOLU'),
(942, 'VAN', 'MURADİYE'),
(943, 'VAN', 'ÖZALP'),
(944, 'VAN', 'SARAY'),
(945, 'VAN', 'TUŞBA'),
(946, 'YALOVA', 'ALTINOVA'),
(947, 'YALOVA', 'ARMUTLU'),
(948, 'YALOVA', 'ÇINARCIK'),
(949, 'YALOVA', 'ÇİFTLİKKÖY'),
(950, 'YALOVA', 'MERKEZ'),
(951, 'YALOVA', 'TERMAL'),
(952, 'YOZGAT', 'AKDAĞMADENİ'),
(953, 'YOZGAT', 'AYDINCIK'),
(954, 'YOZGAT', 'BOĞAZLIYAN'),
(955, 'YOZGAT', 'ÇANDIR'),
(956, 'YOZGAT', 'ÇAYIRALAN'),
(957, 'YOZGAT', 'ÇEKEREK'),
(958, 'YOZGAT', 'KADIŞEHRİ'),
(959, 'YOZGAT', 'MERKEZ'),
(960, 'YOZGAT', 'SARAYKENT'),
(961, 'YOZGAT', 'SARIKAYA'),
(962, 'YOZGAT', 'SORGUN'),
(963, 'YOZGAT', 'ŞEFAATLİ'),
(964, 'YOZGAT', 'YENİFAKILI'),
(965, 'YOZGAT', 'YERKÖY'),
(966, 'ZONGULDAK', 'ALAPLI'),
(967, 'ZONGULDAK', 'ÇAYCUMA'),
(968, 'ZONGULDAK', 'DEVREK'),
(969, 'ZONGULDAK', 'EREĞLİ'),
(970, 'ZONGULDAK', 'GÖKÇEBEY'),
(971, 'ZONGULDAK', 'KİLİMLİ'),
(972, 'ZONGULDAK', 'KOZLU'),
(973, 'ZONGULDAK', 'MERKEZ');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `homePhone` varchar(255) NOT NULL,
  `addressName` varchar(255) NOT NULL,
  `il` varchar(255) NOT NULL,
  `ilce` varchar(255) NOT NULL,
  `addressDetail` varchar(255) NOT NULL,
  `makbuz` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `ip` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `firstName`, `lastName`, `homePhone`, `addressName`, `il`, `ilce`, `addressDetail`, `makbuz`, `type`, `ip`) VALUES
(31, 'asdasd', 'asdasd', '+90 555 555 55 55', 'asd', 'ADIYAMAN', 'ÇELİKHAN', 'asdasdas das as das das as d', '1-d1813e31ea.jpg', 'Havale', '54.209.49.145'),
(32, 'asdasd', 'asdasd', '+90 555 555 55 55', 'asdasd a dsa', 'ADANA', 'YUMURTALIK', 'a sd sasa dsa das as das', '', '3D', '54.209.49.145');

-- --------------------------------------------------------

--
-- Table structure for table `ip2`
--

CREATE TABLE `ip2` (
  `ip2` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ip2`
--

INSERT INTO `ip2` (`ip2`) VALUES
('10.1.1.2'),
('10.1.1.2'),
('10.1.1.2'),
('10.1.1.2'),
('10.1.1.2'),
('::1'),
('::1');

-- --------------------------------------------------------

--
-- Table structure for table `ip3`
--

CREATE TABLE `ip3` (
  `ip3` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ip3`
--

INSERT INTO `ip3` (`ip3`) VALUES
('10.1.1.2'),
('10.1.1.2');

-- --------------------------------------------------------

--
-- Table structure for table `ip4`
--

CREATE TABLE `ip4` (
  `ip4` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'admin', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `3d`
--
ALTER TABLE `3d`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ilan`
--
ALTER TABLE `ilan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ilan_bos`
--
ALTER TABLE `ilan_bos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ilan_playstation`
--
ALTER TABLE `ilan_playstation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ilan_telefon`
--
ALTER TABLE `ilan_telefon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ilceler`
--
ALTER TABLE `ilceler`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `3d`
--
ALTER TABLE `3d`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ilan`
--
ALTER TABLE `ilan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ilan_bos`
--
ALTER TABLE `ilan_bos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `ilan_playstation`
--
ALTER TABLE `ilan_playstation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ilan_telefon`
--
ALTER TABLE `ilan_telefon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `ilceler`
--
ALTER TABLE `ilceler`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=974;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
