<!DOCTYPE html>
<html lang="tr">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="dinamikstyle/style.css">
<meta charset="UTF-8">
<title>Sahibinden Panel MelaGor | Anasayfa</title>
</head>
<body>
<center>
<h3>Güncellemeler</h3>
<li>27/09/2023 / Artık ilanlarınızı uygulama şeklinde yollayabileceksiniz. Uygulama linkine ulaşmak için İlan > Listele > Uygulama Linki şeklinde yapınız.
</li>

<li>27/09/2023 / İlan düzenlerken; "İlan Fotoğrafı", "İlan Fiyatı", "Hizmet Bedeli", "IBAN Bilgisi" alanlarının yeniden doldurulması gerekmektedir. Aksi taktirde sayfa hata verir (yakında bir çözüm bulunacak). İlan düzenlemek yerine "Toplu İşlemler" menüsünde istediğiniz bilgiyi kolayca tek tuşla değiştirebilirsiniz.
</li>
</center>


</body>
</html>