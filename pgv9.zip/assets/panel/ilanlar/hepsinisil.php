<?php
include('../../../settings/router.php');
session_start();
if (empty($_SESSION['username'])) {
    header("location: https://www.youtube.com/watch?v=ezxYxeTDxTM");
}

if (!empty($_SESSION['username'])) {
    $db = new PDO($dsn, $user, $password);
    
    $query = $db->prepare("DELETE FROM ilan_bos");
    $delete = $query->execute();

    if ($delete) {
        header("Location:../index.php?page=ilanlar&action=list");
    }
}
?>
