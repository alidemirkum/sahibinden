<?php
header('Location: ../assets/panel/login.php');
exit();
?>