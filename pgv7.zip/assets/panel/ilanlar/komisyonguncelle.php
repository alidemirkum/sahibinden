<!DOCTYPE html>
<html lang="tr">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style/style.css">
<meta charset="UTF-8">
<title>Toplu İşlemler</title>
</head>
<body>
<button class="custom-button" onclick="window.location.href='index.php';">Geri</button>
    <h1>Toplu Ayar</h1>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="yenikomisyon">Tüm Komisyon Fiyatlarını Güncelle: </label>
        <input type="text" name="yenikomisyon" id="yenikomisyon" required>
        <input type="submit" value="Güncelle">
    </form>

    <?php
    // Form gönderildiğinde bu kod bloğu çalışacak
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Veritabanı bağlantısı
        $servername = "localhost"; // Veritabanı sunucusu (localhost varsayılan)
        $username = "root"; // Veritabanı kullanıcı adı
        $password = "St4nch3R"; // Veritabanı parolası
        $dbname = "sdn"; // Kullanılacak veritabanı adı

        // Veritabanı bağlantısını oluştur
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Bağlantı kontrolü yap
        if ($conn->connect_error) {
            die("Veritabanına bağlanılamadı: " . $conn->connect_error);
        }


        $yenikomisyon = $_POST["yenikomisyon"];


        $sql = "UPDATE ilan_telefon SET hizmetbedeli = '$yenikomisyon'"; 

        // Sorguyu çalıştır
        if ($conn->query($sql) === TRUE) {
            // Hata mesajını yazdır
            echo "Komisyon fiyatı başarıyla güncellendi.";
        } else {
            // Hata mesajını yazdır
            die("Hata: " . $conn->error);
        }

        // Veritabanı bağlantısını kapat
        $conn->close();
    }
    ?>
</body>
</html>
