<!DOCTYPE html>
<?php
require "baglan.php";
ob_start();
session_start();
if(empty($_SESSION['username']))
{
  header("location:/assets/panel/login.php");
}
?>
<html lang="tr">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style/style.css">
<meta charset="UTF-8">
<title>Toplu İşlemler</title>
</head>
<body>
<button class="custom-button" onclick="window.location.href='index.php';">Geri</button>
    <h1>Toplu Ayar</h1>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
			
			<br>
			<br>
			<label for="seller_phone">Tüm İlanların Satıcı Telefonunu Güncelle: </label>
            <input type="text" name="seller_phone" value="Başında 0 olmadan boşluksuz olarak giriniz" id="seller_phone" required>
            <input type="submit" value="Güncelle">
        </form>
   <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $telefon = $_POST["seller_phone"];
        $duzenlenmisTelefon = "0 (" . substr($telefon, 0, 3) . ") " . substr($telefon, 3, 3) . " " . substr($telefon, 6, 2) . " " . substr($telefon, 8, 2);
        echo "<div>Dönüştürülen Telefon Numarası: $duzenlenmisTelefon</div>";
    }
    ?>

    <?php

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        $servername = "localhost"; 
        $username = "root"; 
        $password = "St4nch3R"; 
        $dbname = "sdn"; 

        $conn = new mysqli($servername, $username, $password, $dbname);


        if ($conn->connect_error) {
            die("Veritabanına bağlanılamadı: " . $conn->connect_error);
        }



		$seller_phone = $_POST["seller_phone"];
		
		$sql = "UPDATE ilan_telefon SET seller_phone = '$seller_phone'"; 
		
		        if ($conn->query($sql) === TRUE) {
            echo "Satıcı Telefon Numarası başarıyla güncellendi.";
        } else {
            die("Hata: " . $conn->error);
        }
				
        $conn->close();
    }
    ?>
	
	
</body>
</html>
