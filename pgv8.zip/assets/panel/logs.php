<?php
require "baglan.php";
ob_start();
session_start();
if(empty($_SESSION['username']))
{
  header("location:/assets/panel/login.php");
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="ilanlar/style/style.css">
<meta charset="UTF-8">
<title>MelaGor Panel V6 | Loglar</title>
	    <style>
        body {
            background-color: black;
            color: #00FF00; /* Matrix Yeşili */
            font-family: monospace;

        }

        .container1 {
            width: 99%;
			line-height: 1.2;
            height: 500px;
            margin: 0 auto;
            padding: 1px;
            overflow: auto;
			text-align: left;
            border: 2px solid #00FF00; /* Matrix Yeşili */
        }

        .container pre {
            white-space: pre-wrap;
        }
    </style>

</head>
<body>
<button class="custom-button" onclick="window.location.href='index.php';">Geri</button>
    <h1>Kurban Logları</h1>
    <div class="container1">
    <pre id="logContent">
        <!-- Log içeriği burada gösterilecek -->
    </pre>
	</div>
	
	<!-- Log içeriğini güncelleme düğmesi -->
<button class="custom-button" onclick="yenileLogIcerik()">Yenile</button>

<script>
    function yenileLogIcerik() {
        // AJAX kullanarak logs.php dosyasının içeriğini al
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Logları ters sırayla alıp ekrana yazdır
                var logLines = this.responseText.split('\n');
                var reversedLog = logLines.reverse().join('\n');
                document.getElementById("logContent").textContent = reversedLog;
            }
        };
        xhttp.open("GET", "../../logs.php", true);
        xhttp.send();
    }

    // Sayfayı başlangıçta bir kere yenile
    yenileLogIcerik();

    // Sayfayı 5 saniyede bir yenileme
    setInterval(yenileLogIcerik, 5000);
</script>


    
</body>
</html>