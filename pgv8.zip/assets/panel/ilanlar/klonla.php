<?php

include('../../../settings/router.php');
session_start();
if (empty($_SESSION['username'])) {
    header("location: https://www.youtube.com/watch?v=ezxYxeTDxTM");
}

$q = $_GET['list'];



if ($q) {
    if (!empty($_SESSION['username'])) {
        $db = new PDO($dsn, $user, $password);

        // Belirli bir satırın verisini al
        $query = $db->prepare("SELECT * FROM ilan_bos WHERE id = :id");
        $query->execute(array(
            'id' => $_GET['id']
        ));
        $row = $query->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            // Kopya oluştur
            $query = $db->prepare("INSERT INTO ilan_bos (seller_name, seller_phone, ilanurl, ilanad, ilanfiyat, ilan_resim, il, ilce, mahalle, ilan_no, ilan_date, color, garanti, fromwho, swap, status, description, hizmetbedeli, banks, hesapsahibi, iban, hesapno, subekodu, katman1, katman1oz, kategori, katman2, katman2oz, katman3, katman3oz, katman4, katman4oz, katman5, katman5oz, katman6, katman6oz, katman7, katman7oz) 
            VALUES (:seller_name, :seller_phone, :ilanurl, :ilanad, :ilanfiyat, :ilan_resim, :il, :ilce, :mahalle, :ilan_no, :ilan_date, :color, :garanti, :fromwho, :swap, :status, :description, :hizmetbedeli, :banks, :hesapsahibi, :iban, :hesapno, :subekodu, :katman1, :katman1oz, :kategori, :katman2, :katman2oz, :katman3, :katman3oz, :katman4, :katman4oz, :katman5, :katman5oz, :katman6, :katman6oz, :katman7, :katman7oz)");
            $insert = $query->execute(array(
                'seller_name' => $row['seller_name'],
                'seller_phone' => $row['seller_phone'],
                'ilanurl' => $row['ilanurl'],
                'ilanad' => $row['ilanad'],
                'ilanfiyat' => $row['ilanfiyat'],
                'ilan_resim' => $row['ilan_resim'],
                'il' => $row['il'],
                'ilce' => $row['ilce'],
                'mahalle' => $row['mahalle'],
                'ilan_no' => $row['ilan_no'],
                'ilan_date' => $row['ilan_date'],
                'color' => $row['color'],
                'garanti' => $row['garanti'],
                'fromwho' => $row['fromwho'],
                'swap' => $row['swap'],
                'status' => $row['status'],
                'description' => $row['description'],
                'hizmetbedeli' => $row['hizmetbedeli'],
                'banks' => $row['banks'],
                'hesapsahibi' => $row['hesapsahibi'],
                'iban' => $row['iban'],
                'hesapno' => $row['hesapno'],
                'subekodu' => $row['subekodu'],
                'katman1' => $row['katman1'],
                'katman1oz' => $row['katman1oz'],
                'kategori' => $row['kategori'],
                'katman2' => $row['katman2'],
                'katman2oz' => $row['katman2oz'],
                'katman3' => $row['katman3'],
                'katman3oz' => $row['katman3oz'],
                'katman4' => $row['katman4'],
                'katman4oz' => $row['katman4oz'],
                'katman5' => $row['katman5'],
                'katman5oz' => $row['katman5oz'],
                'katman6' => $row['katman6'],
                'katman6oz' => $row['katman6oz'],
                'katman7' => $row['katman7'],
                'katman7oz' => $row['katman7oz']
            ));

            if ($insert) {
                // Yeni satırın id'sini al
                $newId = $db->lastInsertId();
                header("Location:../index.php?page=ilanlar&action=list");
            }
        }
    }
} else {
    if (!empty($_SESSION['username'])) {
        $db = new PDO($dsn, $user, $password);

        // Belirli bir satırı sil
        $query = $db->prepare("DELETE FROM info WHERE id = :id");
        $delete = $query->execute(array(
            'id' => $_GET['id']
        ));

        if ($delete) {
            header("Location:../index.php?page=ilanlar&action=log");
        }
    }
}




?>