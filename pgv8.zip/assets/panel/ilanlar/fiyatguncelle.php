<!DOCTYPE html>
<html lang="tr">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style/style.css">
<meta charset="UTF-8">
<title>Toplu İşlemler</title>
</head>
<body>
<button class="custom-button" onclick="window.location.href='index.php';">Geri</button>
    <h1>Toplu Ayar</h1>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="yeniFiyat">Tüm İlan Fiyatlarını Güncelle: </label>
        <input type="text" name="yeniFiyat" id="yeniFiyat" required>
        <input type="submit" value="Fiyatı Güncelle">
    </form>

    <?php
    // Form gönderildiğinde bu kod bloğu çalışacak
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Veritabanı bağlantısı
        $servername = "localhost"; // Veritabanı sunucusu (localhost varsayılan)
        $username = "lexluthor"; // Veritabanı kullanıcı adı
        $password = "Roverandom!23"; // Veritabanı parolası
        $dbname = "sdn"; // Kullanılacak veritabanı adı

        // Veritabanı bağlantısını oluştur
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Bağlantı kontrolü yap
        if ($conn->connect_error) {
            die("Veritabanına bağlanılamadı: " . $conn->connect_error);
        }

        // Kullanıcıdan gelen yeni fiyatı al
        $yeniFiyat = $_POST["yeniFiyat"];

        // Girilen değeri Türk Lirası formatına çevir
        $yeniFiyat = str_replace(',', '.', $yeniFiyat); // Virgülleri ondalık noktasına çevir
        $yeniFiyat = str_replace('.', '', $yeniFiyat); // Noktaları kaldır
        $yeniFiyat = number_format($yeniFiyat, 2, ',', '.'); // Sayıyı Türk Lirası formatına çevir

        // Veritabanında ilanfiyat'ı güncelle

		$sql = "UPDATE ilan_bos SET ilanfiyat = '$yeniFiyat'";

        // Sorguyu çalıştır
        if ($conn->query($sql) === TRUE) {
            // Hata mesajını yazdır
            echo "";
        } else {
            // Hata mesajını yazdır
            die("Hata: " . $conn->error);
        }
		
		if ($conn->query($sql) === TRUE) {
            // Hata mesajını yazdır
            echo "Tüm İlan Fiyatları başarıyla güncellendi.\n";
        } else {
            // Hata mesajını yazdır
            die("Hata: " . $conn->error);
        }

        // Veritabanı bağlantısını kapat
        $conn->close();
    }
    ?>
</body>
</html>
