<?php
$page = "edit";
include "bos.php";
?>

</div>
</body>
</html>
