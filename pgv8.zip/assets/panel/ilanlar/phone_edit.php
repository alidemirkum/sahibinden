<?php
$page = "edit";
include "telefon.php";
?>

</div>
</body>
</html>
