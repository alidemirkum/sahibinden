<?php
//$dbname = Database adı
//$user =  Database kullanıcı adı
//$password = Database şifre
//buna göre düzelt

$dbname = 'sdn';
$user = 'lexluthor';
$password = 'Roverandom!23';
$dsn = 'mysql:host=localhost;charset=utf8;dbname='.$dbname;

?>