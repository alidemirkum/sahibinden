<!DOCTYPE html>
<html lang="tr">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style/style.css">
<meta charset="UTF-8">
<title>Toplu İşlemler</title>
</head>
<body>
<button class="custom-button" onclick="window.location.href='index.php';">Geri</button>
    <h1>Toplu Ayar</h1>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
			
			<br>
			<br>
			<label for="seller_name">Tüm İlanların Satıcı İsim Soyisimlerini Güncelle: </label>
            <input type="text" name="seller_name" id="seller_name" required>
            <input type="submit" value="Güncelle">
        </form>
    

    <?php

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        $servername = "localhost"; 
        $username = "root"; 
        $password = ""; 
        $dbname = "sdn"; 

        $conn = new mysqli($servername, $username, $password, $dbname);


        if ($conn->connect_error) {
            die("Veritabanına bağlanılamadı: " . $conn->connect_error);
        }



		$seller_name = $_POST["seller_name"];
		
		$sql = "UPDATE ilan_telefon SET seller_name = '$seller_name'"; 
		
		        if ($conn->query($sql) === TRUE) {
            echo "Satıcı İsim-Soyisim başarıyla güncellendi.";
        } else {
            die("Hata: " . $conn->error);
        }
				
        $conn->close();
    }
    ?>
	
	
</body>
</html>
