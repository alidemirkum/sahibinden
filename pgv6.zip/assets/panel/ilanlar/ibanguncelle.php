<!DOCTYPE html>
<html lang="tr">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style/style.css">
<meta charset="UTF-8">
<title>Toplu İşlemler</title>

</head>
<body>   
<button class="custom-button" onclick="window.location.href='index.php';">Geri</button>
  

<h1>Toplu İşlemler</h1>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
			<label for="banka">Tüm İlanların IBAN Bilgilerini Güncelle: </label>
			<select name="banka" name="banka" id="banka" class="form-control">
                            <option value="0" disabled selected>Seçim Yapınız</option>
                            <option value="Ziraat Bankası">Ziraat Bankası</option>
                            <option value="İş Bankası">İş Bankası</option>
                            <option value="Halk Bankası">Halk Bankası</option>
                            <option value="VakıfBank">VakıfBank</option>
                            <option value="Garanti Bankası">Garanti Bankası</option>
                            <option value="Yapı ve Kredi Bankası">Yapı ve Kredi Bankası</option>
                            <option value="Akbank">Akbank</option>
                            <option value="QNB Finansbank">QNB Finansbank</option>
                            <option value="Denizbank">Denizbank</option>
                            <option value="PTT">PTT</option>
                            <option value="Kuveyt">Kuveyt</option>
                            <option value="Türkiye Finans">Türkiye Finans</option>
                        </select>
			<br>
			<br>
			<label for="hesapsahibi">İsim Soyisim: </label>
            <input type="text" name="hesapsahibi" id="hesapsahibi" required>
			<br>
			<br>
            <label for="yeniiban">IBAN No: </label>
			<input type="text" name="yeniiban" id="yeniiban" required>
			<br>
			<br>
            <input type="submit" value="Güncelle">
        </form>
    

    <?php

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        $servername = "localhost"; 
        $username = "root"; 
        $password = ""; 
        $dbname = "sdn"; 


        $conn = new mysqli($servername, $username, $password, $dbname);


        if ($conn->connect_error) {
            die("Veritabanına bağlanılamadı: " . $conn->connect_error);
        }


        $yeniiban = $_POST["yeniiban"];


        $sql = "UPDATE ilan_telefon SET iban = '$yeniiban'"; 
		

        if ($conn->query($sql) === TRUE) {
            echo "İban adresleri başarıyla güncellendi.";
        } else {
            die("Hata: " . $conn->error);
        }




		$hesapsahibi = $_POST["hesapsahibi"];
		
		$sql = "UPDATE ilan_telefon SET hesapsahibi = '$hesapsahibi'"; 
		
		        if ($conn->query($sql) === TRUE) {
            echo "İban İsim-Soyisim başarıyla güncellendi.";
        } else {
            die("Hata: " . $conn->error);
        }
		
		
		$banka = $_POST["banka"];
		
		$sql = "UPDATE ilan_telefon SET banks = '$banka'"; 
		
		        if ($conn->query($sql) === TRUE) {
            echo "Banka başarıyla güncellendi.";
        } else {
            die("Hata: " . $conn->error);
        }
		
		
		
        $conn->close();
    }
    ?>
	

	
</body>
</html>
