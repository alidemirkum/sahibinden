<style>
        /* CSS Stil Kodları */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }

        .modal {
            background-color: #fff;
            width: 200px;
            height: 200px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            text-align: center;
            padding: 20px;
            position: relative;
        }

        .close {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
        }
    </style>
    <title>Bildirim Kutusu</title>
</head>
<body>
    <div class="overlay" id="overlay">
        <div class="modal">
            <span class="close" id="close">&times;</span>
            <p>Merhaba, bu bir bildirim kutusudur.</p>
        </div>
    </div>

    <script>
        // JavaScript Kodları
        const overlay = document.getElementById("overlay");
        const close = document.getElementById("close");

        // Bildirim kutusunu göster
        function showNotification() {
            overlay.style.display = "flex";
        }

        // Bildirim kutusunu gizle
        function closeNotification() {
            overlay.style.display = "none";
        }

        // Kapatma işaretine tıklanınca bildirim kutusunu gizle
        close.addEventListener("click", closeNotification);

        // Sayfa yüklendiğinde bildirim kutusunu göster (örnek olarak)
        window.addEventListener("load", showNotification);
    </script>