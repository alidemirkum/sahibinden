<?php
$page = "edit";
include "form.php";
?>

</div>
</body>
</html>
